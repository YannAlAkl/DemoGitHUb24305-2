const AccueilView = () => `
    <section class="hero-section">
        <div class="card" >
            <img src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=1200&h=400&fit=crop" alt="Gym" style="width: 100%; height: 250px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;">
            <h1 id='page-title'>Bienvenue chez FitLife Gym 💪</h1>
            <p class="paragraphe">Transformez votre corps et votre esprit chez FitLife Gym, où le fitness rencontre la communauté. Notre installation ultramoderne offre tout ce dont vous avez besoin pour atteindre vos objectifs de santé et de bien-être.</p>
        </div>
    </section>

    <div class="two-col" style="margin-top: 20px;">
        <div class="card">
            <img src="https://images.unsplash.com/photo-1571902943202-507ec2618e8f?w=600&h=300&fit=crop" alt="Entraînement" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;">
            <h2>Pourquoi Choisir FitLife?</h2>
            <p class="paragraphe">Chez FitLife Gym, nous croyons que le fitness est un voyage, pas une destination. Nos entraîneurs experts sont dédiés à vous aider à atteindre votre meilleur niveau, que vous soyez débutant ou athlète avancé.</p>
            <p class="paragraphe">Avec des équipements de pointe, une offre de cours diversifiée et une communauté solidaire, vous trouverez tout ce dont vous avez besoin sous un même toit. Du cardio à la musculation, en passant par le yoga et le HIIT, nous avons tout prévu.</p>
        </div>
        
        <div class="card">
            <h2>Nos Installations</h2>
            <ul style="color: var(--white); line-height: 1.8;">
                <li>🏋️ Zone de musculation moderne</li>
                <li>🏃 Zone cardio avec équipement premium</li>
                <li>🧘 Studio de yoga et étirements dédié</li>
                <li>🥊 Espace d'entraînement fonctionnel</li>
                <li>🚿 Vestiaires et douches de luxe</li>
                <li>☕ Bar à smoothies et coin nutrition</li>
            </ul>
            <img src="https://images.unsplash.com/photo-1540497077202-7c8a3999166f?w=600&h=200&fit=crop" alt="Installations" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px; margin-top: 15px;">
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: center;">
            <div>
                <h2>Avantages d'Adhésion</h2>
                <p class="paragraphe">Rejoignez FitLife aujourd'hui et débloquez l'accès à des cours illimités, des séances d'entraînement personnel, des conseils nutritionnels et des événements exclusifs pour membres. Nos plans d'adhésion flexibles sont conçus pour s'adapter à votre style de vie et à votre budget.</p>
                <p class="paragraphe">Les nouveaux membres reçoivent une évaluation de condition physique gratuite et un plan d'entraînement personnalisé. De plus, amenez un ami gratuitement pendant votre premier mois!</p>
            </div>
            <img src="https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?w=600&h=400&fit=crop" alt="Groupe" style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px;">
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <h2>Commencez Votre Parcours Fitness Aujourd'hui</h2>
        <p class="paragraphe">Prêt à faire un changement? Que vous souhaitiez développer votre force, perdre du poids, améliorer votre flexibilité ou simplement vous sentir mieux, FitLife Gym est là pour vous soutenir à chaque étape. Notre communauté vous attend!</p>
        <p class="paragraphe" style="text-align: center; margin-top: 20px;"><strong>Visitez-nous au 123 Avenue du Fitness, ou appelez le (555) 123-4567 pour planifier votre essai gratuit dès aujourd'hui!</strong></p>
    </div>
`;
