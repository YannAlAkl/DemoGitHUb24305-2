const ContactView = () => /*html*/`
    <div class="two-col" style="grid-template-columns: 1fr 400px;">
        <div class="card">
            <h1 id='page-title'>Contactez-Nous</h1>
            <p class="paragraphe">Vous avez des questions sur l'adhésion, les cours ou nos installations? Nous serions ravis de vous entendre! Remplissez le formulaire et notre équipe vous répondra dans les 24 heures.</p>
            
            <form id="formContact" action="" method="get" style="margin-top: 20px;">
                <label for="nom">Nom Complet</label>
                <input id="nom" name="nom" type="text" placeholder="Jean Dupont" required>
                
                <label for="email">Adresse Email</label>
                <input id="email" name="email" type="email" placeholder="jean@exemple.com" required>
                
                <label for="message">Message</label>
                <textarea id="message" name="message" placeholder="Dites-nous comment nous pouvons vous aider..." required></textarea>
                
                <button class="btn btn-primary" type="submit" style="margin-top: 15px; width: 100%;">Envoyer le Message 📧</button>
            </form>
        </div>

        <div>
            <div class="card">
                <img src="https://images.unsplash.com/photo-1593642532400-2682810df593?w=400&h=250&fit=crop" alt="Contactez" style="width: 100%; height: 180px; object-fit: cover; border-radius: 8px; margin-bottom: 15px;">
                <h2>Visitez-Nous</h2>
                <p class="paragraphe" style="margin-top: 15px;">
                    <strong>FitLife Gym</strong><br>
                    123 Avenue du Fitness<br>
                    Suite 100<br>
                    Montréal, QC H3B 2E5
                </p>
                
                <h3 style="margin-top: 20px; color: var(--accent);">Heures d'Ouverture</h3>
                <p class="paragraphe" style="line-height: 1.6;">
                    Lundi - Vendredi: 5h00 - 23h00<br>
                    Samedi: 6h00 - 22h00<br>
                    Dimanche: 7h00 - 21h00
                </p>

                <h3 style="margin-top: 20px; color: var(--accent);">Coordonnées</h3>
                <p class="paragraphe" style="line-height: 1.6;">
                    📞 Téléphone: (555) 123-4567<br>
                    📧 Email: info@fitlifegym.com<br>
                    💬 Texto: (555) 123-4568
                </p>
            </div>

            <div class="card" style="margin-top: 20px;">
                <h3>Suivez-Nous</h3>
                <p class="paragraphe" style="line-height: 1.8;">
                    Restez connecté pour des conseils d'entraînement, des histoires de réussite et des offres spéciales!
                </p>
                <div style="display: flex; gap: 10px; margin-top: 15px;">
                    <span class="badge" style="cursor: pointer;">Instagram</span>
                    <span class="badge" style="cursor: pointer;">Facebook</span>
                    <span class="badge" style="cursor: pointer;">Twitter</span>
                </div>
            </div>
        </div>
    </div>
`;
