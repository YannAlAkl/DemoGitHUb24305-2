const AProposView = () => `
    <div class="card">
        <img src="https://images.unsplash.com/photo-1576678927484-cc907957088c?w=1200&h=300&fit=crop" alt="FitLife Gym" style="width: 100%; height: 250px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;">
        <h1 id='page-title'>À Propos de FitLife Gym</h1>
        <p class="paragraphe">Fondé en 2015, FitLife Gym transforme des vies grâce au fitness depuis près d'une décennie. Ce qui a commencé comme une petite salle de sport de quartier est devenu une destination fitness de premier plan, au service de milliers de membres dans notre communauté.</p>
    </div>

    <div class="two-col" style="margin-top: 20px;">
        <div class="card">
            <h2>Notre Mission</h2>
            <p class="paragraphe">Chez FitLife, nous sommes plus qu'une simple salle de sport—nous sommes une communauté dédiée à vous aider à atteindre vos objectifs de santé et de fitness. Nous croyons que tout le monde mérite un accès à des installations de fitness de classe mondiale, des conseils d'experts et un environnement de soutien.</p>
            <p class="paragraphe">Notre mission est d'inspirer et de responsabiliser les individus à vivre des vies plus saines, plus fortes et plus épanouissantes grâce au fitness, à la nutrition et au soutien communautaire.</p>
            <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&h=250&fit=crop" alt="Mission" style="width: 100%; height: 180px; object-fit: cover; border-radius: 8px; margin-top: 15px;">
        </div>

        <div class="card">
            <h2>Nos Valeurs</h2>
            <ul style="color: var(--white); line-height: 1.8;">
                <li><strong>Excellence:</strong> Fournir des installations et services de premier ordre</li>
                <li><strong>Communauté:</strong> Construire des relations durables</li>
                <li><strong>Innovation:</strong> Rester à la pointe avec des techniques modernes</li>
                <li><strong>Intégrité:</strong> Des pratiques honnêtes et transparentes</li>
                <li><strong>Inclusivité:</strong> Accueillir tous les niveaux de fitness</li>
            </ul>
            <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=600&h=250&fit=crop&flip=h" alt="Valeurs" style="width: 100%; height: 180px; object-fit: cover; border-radius: 8px; margin-top: 15px;">
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <h2>Rencontrez Notre Équipe d'Experts</h2>
        <p class="paragraphe">Nos entraîneurs certifiés apportent des décennies d'expérience combinée en entraînement personnel, nutrition, science du sport et réhabilitation. Chaque membre de l'équipe est passionné par votre réussite et engagé dans votre croissance personnelle.</p>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px; margin-top: 20px;">
            <div style="padding: 15px; background: rgba(255,255,255,0.03); border-radius: 8px; text-align: center;">
                <img src="https://images.unsplash.com/photo-1567013275277-90ee3f48e9ca?w=300&h=300&fit=crop" alt="Marcus" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;">
                <h3 style="color: var(--accent);">💪 Marcus Johnson</h3>
                <p style="font-size: 13px; color: var(--muted);">Entraîneur Principal | 15+ ans d'expérience</p>
                <p style="font-size: 14px;">Spécialisé en musculation et performance athlétique</p>
            </div>
            <div style="padding: 15px; background: rgba(255,255,255,0.03); border-radius: 8px; text-align: center;">
                <img src="https://images.unsplash.com/photo-1594381898411-846e7d193883?w=300&h=300&fit=crop" alt="Sarah" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;">
                <h3 style="color: var(--accent);">🧘 Sarah Chen</h3>
                <p style="font-size: 13px; color: var(--muted);">Directrice Yoga & Bien-être</p>
                <p style="font-size: 14px;">Instructrice de yoga certifiée et coach santé holistique</p>
            </div>
            <div style="padding: 15px; background: rgba(255,255,255,0.03); border-radius: 8px; text-align: center;">
                <img src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=300&h=300&fit=crop" alt="David" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 10px;">
                <h3 style="color: var(--accent);">🥊 David Martinez</h3>
                <p style="font-size: 13px; color: var(--muted);">Spécialiste HIIT & Boxe</p>
                <p style="font-size: 14px;">Ancien athlète professionnel, expert cardio</p>
            </div>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: center;">
            <img src="https://images.unsplash.com/photo-1558611848-73f7eb4001a1?w=600&h=400&fit=crop" alt="Installations" style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px;">
            <div>
                <h2>Notre Installation Ultramoderne</h2>
                <p class="paragraphe">Entrez dans notre installation de 25 000 pieds carrés dotée des dernières technologies de fitness. Des plateformes de levage olympiques aux machines cardio avancées avec systèmes de divertissement intégrés, nous avons équipé notre espace de tout ce dont vous avez besoin pour atteindre vos objectifs.</p>
                <p class="paragraphe">Nous maintenons les normes les plus élevées de propreté et d'entretien des équipements, assurant un environnement d'entraînement sûr et confortable pour tous les membres.</p>
            </div>
        </div>
    </div>

    <div class="card" style="margin-top: 20px;">
        <h2>Communauté & Réussites</h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; align-items: center;">
            <div>
                <p class="paragraphe">Nos membres sont le cœur de FitLife. Nous avons aidé des centaines de personnes à réaliser des transformations incroyables—des parcours de perte de poids aux marathons complets, des novices en salle de sport aux athlètes compétitifs. Votre succès est notre succès.</p>
                <p class="paragraphe">Rejoignez-nous pour des événements communautaires réguliers, des défis fitness et des rassemblements sociaux qui rendent le fitness amusant et rapprochent notre communauté.</p>
            </div>
            <img src="https://images.unsplash.com/photo-1552196563-55cd4e45efb3?w=600&h=400&fit=crop" alt="Communauté" style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px;">
        </div>
    </div>
`;
