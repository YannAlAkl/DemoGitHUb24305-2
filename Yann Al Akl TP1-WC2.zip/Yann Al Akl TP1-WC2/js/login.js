const LoginView = () => /*html*/`
    <div class="card" style="max-width: 500px; margin: 0 auto;">
        <img src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=500&h=200&fit=crop" alt="Login" style="width: 100%; height: 180px; object-fit: cover; border-radius: 8px; margin-bottom: 20px;">
        <h1 id='page-title' style="text-align: center;">Connexion Membre 🔐</h1>
        <p class="paragraphe" style="text-align: center; margin-bottom: 25px;">Accédez à votre compte FitLife pour consulter votre profil, suivre vos entraînements et gérer votre adhésion.</p>
        
        <form id="formLogin" action="" method="get">
            <label for="email">Adresse Email</label>
            <input id="email" name="email" type="email" placeholder="votre.email@exemple.com" required>
            
            <label for="password">Mot de Passe</label>
            <input id="password" name="password" type="password" placeholder="Entrez votre mot de passe" required>
            
            <button class="btn btn-primary" type="submit" style="width: 100%; margin-top: 20px; padding: 12px;">Se Connecter</button>
        </form>

        <div style="margin-top: 25px; padding-top: 20px; border-top: 1px solid rgba(255,255,255,0.1); text-align: center;">
            <p style="font-size: 13px; color: var(--muted); margin: 0;">
                Pas encore de compte? <span style="color: var(--accent); cursor: pointer; font-weight: 600;">Inscrivez-vous pour un essai gratuit</span>
            </p>
        </div>

        <div style="margin-top: 25px; padding: 15px; background: rgba(255,255,255,0.03); border-radius: 8px;">
            <p style="font-size: 13px; color: var(--muted); margin: 0; line-height: 1.6;">
                <strong>Comptes de démo:</strong><br>
                alice@ex.com / pass1 (Membre Premium)<br>
                bob@ex.com / pass2 (Coach)<br>
                caro@ex.com / pass3 (Membre Standard)
            </p>
        </div>
    </div>
`;
